class GestorCookies {
    static setCookie(nombre, valor, dias) {
        const fecha = new Date();
        fecha.setTime(fecha.getTime() + (dias * 24 * 60 * 60 * 1000));
        document.cookie = `${nombre}=${valor};expires=${fecha.toUTCString()};path=/`;
    }

    static getCookie(nombre) {
        const nameEQ = `${nombre}=`;
        const cookies = document.cookie.split(';');
        for (let i = 0; i < cookies.length; i++) {
            let c = cookies[i];
            while (c.charAt(0) === ' ') c = c.substring(1, c.length);
            if (c.indexOf(nameEQ) === 0) return c.substring(nameEQ.length, c.length);
        }
        return null;
    }

    static deleteCookie(nombre) {
        document.cookie = `${nombre}=; Max-Age=-99999999;`;
    }
}

class GestorSesiones {
    static setSessionItem(nombre, valor) {
        sessionStorage.setItem(nombre, JSON.stringify(valor));
    }

    static getSessionItem(nombre) {
        const item = sessionStorage.getItem(nombre);
        return item ? JSON.parse(item) : null;
    }

    static deleteSessionItem(nombre) {
        sessionStorage.removeItem(nombre);
    }
}

class GestorTareas {
    constructor() {
        this.tareas = GestorSesiones.getSessionItem('tareas') || [];
        this.personas = GestorSesiones.getSessionItem('personas') || [];
        this.inputTarea = document.getElementById("nueva-tarea");
        this.selectPersona = document.getElementById("select-persona");
        this.listaTareas = document.getElementById("lista-tareas");
        this.listaFinalizadas = document.getElementById("lista-finalizadas");
        this.inputPersona = document.getElementById("nueva-persona");
        this.listaPersonas = document.getElementById("lista-personas");
        this.listaBorrarPersonas = document.getElementById("lista-borrar-personas");
        this.frasesMotivadoras = [
            "¡Puedes lograrlo! Sólo da un paso a la vez.",
            "La organización es la clave del éxito.",
            "Cada tarea completada te acerca más a tus metas.",
            "El esfuerzo de hoy es el éxito de mañana.",
            "Nunca subestimes el poder de una lista bien hecha.",
            "Mantén tu objetivo en mente, así dejas menos espacio para la duda.",
            "¡Sin excusas!",
            "Lo intento, me caigo, me levanto.",
            "Las tareas pequeñas son más grandes que una tarea que no está hecha."
        ];

        document.getElementById("form-agregar").addEventListener("submit", (event) => this.addTarea(event));
        document.getElementById("form-agregar-persona").addEventListener("submit", (event) => this.addPersona(event));

        this.mostrarFraseMotivadora();
        this.cargarPersonas();
        this.mostrarTareas();
    }

    addTarea(event) {
        event.preventDefault();
        const texto = this.inputTarea.value.trim();
        const persona = this.selectPersona.value;

        const tareaValida = /^[a-zA-Z0-9áéíóúÁÉÍÓÚñÑ.,!?\s]+$/.test(texto);

        if (texto && persona) {
            if (tareaValida) {
                this.tareas.push({ texto, persona, finalizada: false });
                this.inputTarea.value = "";
                this.mostrarTareas();
                this.mostrarFraseMotivadora();
                GestorSesiones.setSessionItem('tareas', this.tareas);
            } else {
                alert("Solo se permiten letras, números y signos de puntuación.");
                this.inputPersona.value = "";
            }
        } else {
            alert("Por favor, completa todos los campos.");
        }
    }

    addPersona(event) {
        event.preventDefault();
        const persona = this.inputPersona.value.trim();

        const nombreValido = /^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]+$/.test(persona);

        if (persona) {
            if (nombreValido && !this.personas.includes(persona)) {
                this.personas.push(persona);
                this.inputPersona.value = "";
                this.cargarPersonas();
                GestorSesiones.setSessionItem('personas', this.personas);
            } else if (!nombreValido) {
                alert("El nombre solo puede contener letras y espacios.");
                this.inputPersona.value = "";
            } else {
                alert("Esta persona ya existe.");
                this.inputPersona.value = "";
            }
        } else {
            alert("Por favor, introduce un nombre válido.");
        }
    }

    cargarPersonas() {
        this.selectPersona.innerHTML = '<option value="" disabled selected>Selecciona una persona</option>';
        this.listaPersonas.innerHTML = "";

        this.personas.forEach((persona, index) => {
            const option = document.createElement("option");
            option.value = persona;
            option.textContent = persona;
            this.selectPersona.appendChild(option);

            const personaElemento = document.createElement("li");
            personaElemento.textContent = persona;

            const btnEliminar = document.createElement("button");
            btnEliminar.classList.add("eliminar");
            btnEliminar.innerHTML = "Eliminar";
            btnEliminar.onclick = () => this.eliminarPersona(index);

            personaElemento.appendChild(btnEliminar);
            this.listaPersonas.appendChild(personaElemento);
        });
    }

    mostrarTareas() {
        this.listaTareas.innerHTML = "";

        this.tareas.forEach((tarea, index) => {
            const tareaElemento = document.createElement("li");
            tareaElemento.textContent = `${tarea.texto} (Asignada a: ${tarea.persona})`;

            const btnEliminar = document.createElement("button");
            btnEliminar.classList.add("eliminar");
            btnEliminar.innerHTML = "Eliminar";
            btnEliminar.onclick = () => this.eliminarTarea(index);

            tareaElemento.appendChild(btnEliminar);
            this.listaTareas.appendChild(tareaElemento);
        });
    }

    eliminarTarea(index) {
        const tareaEliminada = this.tareas.splice(index, 1)[0];
        this.listaFinalizadas.innerHTML += `<li>${tareaEliminada.texto} (Asignada a: ${tareaEliminada.persona})</li>`;
        GestorSesiones.setSessionItem('tareas', this.tareas);
        this.mostrarTareas();
    }

    eliminarPersona(index) {
        this.personas.splice(index, 1);
        GestorSesiones.setSessionItem('personas', this.personas);
        this.cargarPersonas();
    }

    mostrarFraseMotivadora() {
        const fraseElemento = document.getElementById("frase-motivadora");
        if (fraseElemento) {
            const aleatorio = Math.floor(Math.random() * this.frasesMotivadoras.length);
            fraseElemento.innerText = this.frasesMotivadoras[aleatorio];
        }
    }

    mostrarSeccion(seccion) {
        const secciones = document.querySelectorAll("section");
        secciones.forEach((sec) => sec.style.display = "none");

        const seccionActiva = document.getElementById(`seccion-${seccion}`);
        if (seccionActiva) {
            seccionActiva.style.display = "block";
        }
    }
}


const gestorTareas = new GestorTareas();
